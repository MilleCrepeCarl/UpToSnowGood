
// Access token "hb8QA5lAayHRYC9MyRD4rrtJhPTk"
// "Authorization: Bearer hb8QA5lAayHRYC9MyRD4rrtJhPTk"
// api key : B7zw1CIDEICf813eIC8yPaaFsUUgyj76
// api secret : A4ngHX64yphClGry
// tzqq4pdjd7dv

var resultView = new Vue({
    el: '#app',
    data: {
        // Ann arbor by default
        postalCode: "60607",
        events: [],
        isData: true
    },
    beforeMount(){
        this.eventFunction()
     },
    methods: {
        eventFunction() {
            let url = "https://app.ticketmaster.com/discovery/v2/events.json?postalCode=" + this.postalCode + "&radius=100&units=miles&sort=date,asc&apikey=1ExblcQfbppYk6qJ6tD13y4IUf3tlot3"
            axios.get(url)
            .then(function (response) {
                console.log('events');
                console.log(response);
                if (!("_embedded" in response.data)) {
                    console.log("No data available in area");
                    this.isData = false;
                    return;
                }
                if (!('events' in response.data._embedded)) {
                    console.log("No data available in area");
                    this.isData = false;
                    return;
                }
                this.isData = true;
                let eventList = response.data._embedded.events;
                for (i in eventList) {
                    let event = {
                        name: eventList[i].name,
                        link: eventList[i].url,
                        image: 'No Image',
                        date: eventList[i].dates.start.localDate,
                        time: eventList[i].dates.start.localTime,
                        venue: 'No Venue Found',
                        address: 'No Address Found'
                    }
                    if ("images" in eventList[i] && eventList[i].images.length > 0) {
                        event.image = eventList[i].images[0].url
                    }
                    if ("_embedded" in eventList[i] && "venues" in eventList[i]._embedded) {
                        event.venue = eventList[i]._embedded.venues[0].name,
                        event.address = eventList[i]._embedded.venues[0].address.line1
                    }
                    // Fix date formatting
                    let year = event.date.substring(0, 4);
                    let month = event.date.substring(5, 7);
                    let day = event.date.substring(8, 10);
                    event.date = month + '/' + day + '/' + year;

                    // Fix time formatting
                    let hour = event.time.substring(0,2);
                    let min = event.time.substring(3,5);
                    if (parseInt(hour) > 12) {
                        event.time = (parseInt(hour) - 12).toString() + ':' + min + 'PM'
                    } else {
                        event.time = hour + ':' + min + 'AM'
                    }
                    this.events.push(event);
                }
            }.bind(this))
            .catch (function (error) {
                console.log(error)
            })
        }
    }
  })
  



              // curl \
            // -X POST \
            // -H "Content-Type: application/x-www-form-urlencoded" \
            // https://test.api.amadeus.com/v1/security/oauth2/token \
            // -d "grant_type=client_credentials&client_id=B7zw1CIDEICf813eIC8yPaaFsUUgyj76&client_secret=A4ngHX64yphClGry"
            
        //   let tokenUrl = 'https://test.api.amadeus.com/v1/security/oauth2/token';
        //   axios.post(tokenUrl, {'headers': {'Content-Type': 'application/x-www-form-urlencoded'},
        //                         'params': {
        //                             'grant_type': 'client_credentials', 
        //                             'client_id': 'B7zw1CIDEICf813eIC8yPaaFsUUgyj76',
        //                             'client_secret': 'A4ngHX64yphClGry'}})
        //   .then(function (response) {
        //     console.log(response)
        //   }.bind(this))
        //   .catch (function (error) {
        //     console.log(error)
        //   })
        //   let airPort = 'DTW'
        //   let url = 'https://test.api.amadeus.com/v2/shopping/hotel-offers?latitude=41.8781&longitude&radius=5&radiusUnit=KM&paymentPolicy=NONE&includeClosed=false&bestRateOnly=true&view=FULL&sort=PRICE';
        //   const AuthStr = 'Bearer ' + 'hb8QA5lAayHRYC9MyRD4rrtJhPTk';
        //   console.log("inside");
        //   axios.get(url, {'headers': {'Authorization': AuthStr}})
        //   .then(function (response) {
        //     console.log(response)
        //   }.bind(this))
        //   .catch (function (error) {
        //     console.log(error)
        //   })