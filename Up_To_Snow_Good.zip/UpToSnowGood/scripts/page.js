var resultView = new Vue({
    el: '#app',
    data: {
        defaultCity: "Ann Arbor, Michigan",
        showMain: true,
        showEvents: false,
        showInfo: false,
        map: null,
        selectedCoordinate: null,
        selectedAnnotation: null,
        selectedCity: null,
        selectedState: null,
        selectedCountryCode: null,
        cityOutput: "Select a city with Shift-Click",
        postalCode: null,
        events: [],
        isData: true,
        apiKey: "e5e1fb074fc191c3becb32a9f19f6e53",
        latitude: null,
        longitude: null,
        cityId: null,
        population: '-',
        populationAA: null,
        time: '-',
        timeAA: null,
        temp: '-',
        tempAA: null,
        feels: '-',
        feelsAA: null,
        sunrise: '-',
        sunriseAA: null,
        sunset: '-',
        sunsetAA: null,
        uvi: '-',
        uviAA: null,
        humidity: '-',
        humidityAA: null,
        weatherInfoAA: null,
        cityInfo: null,
        windspeed: '-',
        windspeedAA: null, 
        imgAA: null,
        currWeatherImg: null,
        aaDescription: '-',
        description: '-',
        covidUS: null,
        covidSel: null,
        country: null,
        confirmed: "Sorry, no information available",
        confirmedUS: null,
        deaths: "Sorry, no information available",
        deathsUS: null,
        recovered: "Sorry, no information available",
        recoveredUS: null,
        cityConfirmed: "Sorry, no information available",
        cityDeaths: "Sorry, no information available",
        cityRecovered: "Sorry, no information available",
        aaConfirmed: "Sorry, no information available",
        aaDeaths: "Sorry, no information available",
        aaRecovered: "Sorry, no information available",
        clouds: null,
        cloudsAA: null,
        visibility: "Sorry, no information available",
        visibilityAA: null,
        dewpoint: null,
        dewpointAA: null,
        hiTemp: '-',
        hiTempAA: null,
        loTemp: '-',
        loTempAA: null

    },
    mounted(){
        this.getCovidUS();
        this.initMap();
        this.getWeatherAA();
        this.getCityTimeAA();
        this.getCityInfoAA();
        console.log(this.deathsUS);
        console.log('gsdfs');
        $('#eventsPage').hide();
    },
    methods: {
        numberWithCommas(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        },
        getCovid: function () {
            if (this.country == "United States") {
                this.country = 'US';
            }
            var settings = {
                "async": true,
                "crossDomain": true,
                "url": "https://covid-19-coronavirus-statistics.p.rapidapi.com/v1/stats?country=" + this.country,
                "method": "GET",
                "headers": {
                    "x-rapidapi-host": "covid-19-coronavirus-statistics.p.rapidapi.com",
                    "x-rapidapi-key": "f3240a8b8fmsha65143c4bf93b46p1a8820jsn787c5abcb46f"
                }
            }
            
            $.ajax(settings).done(function (response) {
                resultView['covidSel'] = response['data']['covid19Stats'];
                resultView['confirmed'] = 0;
                resultView['deaths'] = 0;
                resultView['recovered'] = 0;
                var found = false;
                if (resultView.selectedCity == 'New York') {
                    console.log('yo');
                    resultView.selectedCity = 'New York City';
                }
                
                for (index = 0; index < resultView['covidSel'].length; index++) {
                    var val = resultView['covidSel'][index];
                    resultView['confirmed'] += parseInt(val['confirmed']);
                    resultView['deaths']+= parseInt(val['deaths']);
                    resultView['recovered'] += parseInt(val['recovered']);
                    if (resultView.selectedCity === val['city']) {
                        found = true;
                        resultView['cityConfirmed'] = resultView.numberWithCommas(val['confirmed']);
                        resultView['cityDeaths'] = resultView.numberWithCommas(val['deaths']);
                        resultView['cityRecovered'] = resultView.numberWithCommas(val['recovered']);
                    }
                }
                console.log(resultView['covidSel'].length);
                if (!found) {
                    resultView['cityConfirmed'] = "Sorry, no information available";
                    resultView['cityDeaths'] = "Sorry, no information available";
                    resultView['cityRecovered'] = "Sorry, no information available";
                }
                resultView['confirmed'] = resultView.numberWithCommas(resultView['confirmed']);
                resultView['deaths'] = resultView.numberWithCommas(resultView['deaths']);
                resultView['recovered'] = resultView.numberWithCommas(resultView['recovered']);

            });
          },
          getCovidUS: function () {
            var settings = {
                "async": true,
                "crossDomain": true,
                "url": "https://covid-19-coronavirus-statistics.p.rapidapi.com/v1/stats?country=US",
                "method": "GET",
                "headers": {
                    "x-rapidapi-host": "covid-19-coronavirus-statistics.p.rapidapi.com",
                    "x-rapidapi-key": "f3240a8b8fmsha65143c4bf93b46p1a8820jsn787c5abcb46f"
                }
            }
            
            $.ajax(settings).done(function (response) {
                resultView['covidUS'] = response['data']['covid19Stats'];
                resultView['confirmedUS'] = 0;
                resultView['deathsUS'] = 0;
                resultView['recoveredUS'] = 0;
                console.log(resultView['covidUS']);
                for (index = 0; index < resultView['covidUS'].length; index++) {
                    var val = resultView['covidUS'][index];

                    resultView['confirmedUS'] += parseInt(val['confirmed']);
                    resultView['deathsUS']+= parseInt(val['deaths']);
                    resultView['recoveredUS'] += parseInt(val['recovered']);
                    if ('Ann Arbor' === val['city']) {
                        resultView['aaConfirmed'] = resultView.numberWithCommas(val['confirmed']);
                        resultView['aaDeaths'] = resultView.numberWithCommas(val['deaths']);
                        resultView['aaRecovered'] = resultView.numberWithCommas(val['recovered']);
                    }
                }
                console.log(resultView['covidUS'].length);
                resultView['confirmedUS'] = resultView.numberWithCommas(resultView['confirmedUS']);
                resultView['deathsUS'] = resultView.numberWithCommas(resultView['deathsUS']);
                resultView['recoveredUS'] = resultView.numberWithCommas(resultView['recoveredUS']);

            });
          },
        getWeather: function () {
            axios
              .get("https://api.openweathermap.org/data/2.5/onecall?lat=" + this.latitude + "&lon=" + this.longitude + "&appid=" + this.apiKey + "&units=imperial")
              .then(response => {
                  console.log('weather call');
              console.log(response.data);
              this.weatherInfo = response.data;
              this.time = this.weatherInfo['timezone'] // NOTE just get timezone from weather app and do it from there
              this.temp = this.weatherInfo['current']['temp'];
              this.feels = this.weatherInfo['current']['feels_like'];
              var date = new Date(parseInt(this.weatherInfo['current']['sunrise']) * 1000);
                var hours = date.getHours();
                // Minutes part from the timestamp
                var minutes = "0" + date.getMinutes();
                // Seconds part from the timestamp
                var seconds = "0" + date.getSeconds();

                // Will display time in 10:30:23 format
              this.sunrise = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);

              date = new Date(parseInt(this.weatherInfo['current']['sunset']) * 1000);
              var hours = date.getHours();
              // Minutes part from the timestamp
              var minutes = "0" + date.getMinutes();
              // Seconds part from the timestamp
              var seconds = "0" + date.getSeconds();
              this.sunset = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
              
              this.clouds = this.weatherInfo['current']['clouds'];
              if (!this.weatherInfo['current']['visibility']) {
                  this.visibility = "Sorry, no information available";
              }
              else {
                this.visibility = this.numberWithCommas(this.weatherInfo['current']['visibility']) + " meters";

              }
              this.hiTemp = this.weatherInfo['daily'][0]['temp']['max'];
              this.loTemp = this.weatherInfo['daily'][0]['temp']['min'];
              this.dewpoint = this.weatherInfo['current']['dew_point'];
              this.uvi = this.weatherInfo['current']['uvi'];
              this.humidity = this.weatherInfo['current']['humidity'];
              this.windspeed = this.weatherInfo['current']['wind_speed'];
              this.currWeatherImg = './img/' + this.weatherInfo['current']['weather'][0]['icon'] + '@2x.png';
              this.description = this.weatherInfo['current']['weather'][0]['description'];
              console.log(this.currWeatherImg);
            })
          },
          getWeatherAA: function () {
            axios
              .get("https://api.openweathermap.org/data/2.5/onecall?lat=42.279594&lon=-83.732124&appid=" + this.apiKey + "&units=imperial")
              .then(response => {
              console.log(response.data);
              this.weatherInfoAA = response.data;
              this.timeAA = this.weatherInfoAA['timezone'] // NOTE just get timezone from weather app and do it from there
              this.tempAA = this.weatherInfoAA['current']['temp'];
              this.feelsAA = this.weatherInfoAA['current']['feels_like'];
              var date = new Date(parseInt(this.weatherInfoAA['current']['sunrise']) * 1000);
              var hours = date.getHours();
              // Minutes part from the timestamp
              var minutes = "0" + date.getMinutes();
              // Seconds part from the timestamp
              var seconds = "0" + date.getSeconds();

              // Will display time in 10:30:23 format
                this.sunriseAA = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);

                date = new Date(parseInt(this.weatherInfoAA['current']['sunset']) * 1000);
                var hours = date.getHours();
                // Minutes part from the timestamp
                var minutes = "0" + date.getMinutes();
                // Seconds part from the timestamp
                var seconds = "0" + date.getSeconds();
                this.sunsetAA = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
                this.hiTempAA = this.weatherInfoAA['daily'][0]['temp']['max'];
                this.loTempAA = this.weatherInfoAA['daily'][0]['temp']['min'];
                this.cloudsAA = this.weatherInfoAA['current']['clouds'];
                this.visibilityAA = this.numberWithCommas(this.weatherInfoAA['current']['visibility']);
                this.dewpointAA = this.weatherInfoAA['current']['dew_point'];
              this.uviAA = this.weatherInfoAA['current']['uvi'];
              this.humidityAA = this.weatherInfoAA['current']['humidity'];
              this.windspeedAA = this.weatherInfoAA['current']['wind_speed'];
              this.imgAA = './img/' + this.weatherInfoAA['current']['weather'][0]['icon'] + '@2x.png';
              this.aaDescription = this.weatherInfoAA['current']['weather'][0]['description'];
              
              
              console.log(this.imgAA);
              
            })
          },
          
          getCityId: function () {
            axios
              .get("http://geodb-free-service.wirefreethought.com/v1/geo/cities?limit=5&offset=0&namePrefix=" + this.selectedCity)
              .then(response => {
                  //shit if 1 result vs 2 results ['data'] 
                  console.log('city id call')
                  console.log(response.data);
                  console.log(this.selectedCity)
                  for (city in response.data['data']) {
                      //console.log(response.data['data'][city]);
                      if (response.data['data'][city]['countryCode'] == this.selectedCountryCode) {
                          this.cityId = response.data['data'][city]['id'];
                          console.log(this.cityId)
                          this.getCityInfo();
                          return;
                      }
                  }
                  this.population = "No info, sorry ";
                  console.log('population update ' + this.population);
                  console.log('city id did not retrieve it');
              })
          },
          getCityInfo: function () {
            axios
              .get("http://geodb-free-service.wirefreethought.com/v1/geo/cities/" + this.cityId)
              .then(response => {
              console.log(response.data);
              console.log('getcityinfo');
              this.cityInfo = response.data;
              this.population = this.numberWithCommas(response.data['data']['population']);
              console.log('population update ' + this.population);
              this.getCityTime();
            })
          },
          getCityInfoAA: function () {
            axios
              .get("http://geodb-free-service.wirefreethought.com/v1/geo/cities/Q485172")
              .then(response => {
              console.log(response.data);
              console.log('getcityinfo');
              this.cityInfo = response.data;
              this.populationAA = this.numberWithCommas(response.data['data']['population']);
            })
          },
          getCityTime: function () {
            axios
              .get("http://geodb-free-service.wirefreethought.com/v1/geo/cities/" + this.cityId + "/time")
              .then(response => {
                console.log('wat');
              console.log(response.data);
            })
          },
          getCityTimeAA: function () {
            axios
              .get("http://geodb-free-service.wirefreethought.com/v1/geo/cities/Q485172/time")
              .then(response => {
              console.log(response.data);
              console.log('HMMM');

            })
          },
        initMap() {
            mapkit.init({
                authorizationCallback: function(done) {
                    // TODO: move token to diff file
                    done("eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkQzNEg0WDNHWDMifQ.eyJpc3MiOiI1Mjc1VTUyUTQ0IiwiaWF0IjoxNTgyNjc3NjM3LCJleHAiOjE2MTQyOTc2MDB9.D7i1SkIHLqq3Mt7sJAKZQV9PDbYfa6Jr5GW6t8K6avWWEFSMJ2zPAixeCoB4yiNh0zn63bmsccABmA3bZAn6QQ");
                },
                language: "en"
            }); 
            this.map = new mapkit.Map("map");
            this.map.element.addEventListener("click", this.handleClick);
            this.showMap = true;
            $('#infoPage').hide();

        },
        handleClick(event) {
            if(!event.shiftKey) {
                return;
            }
            // let drag = false;
            // document.addEventListener('mousemove', () => drag = true);
            // if (drag){
            //     console.log("drag");
            //     return;
            // }
            if (event.target.parentNode !== this.map.element) {  
                // This condition prevents clicks on controls. Binding to a   
                // secondary click is another option to prevent conflict  
                return;  
            }
            if (this.selectedAnnotation) {
                this.map.removeAnnotation(this.selectedAnnotation);
            }  
            var domPoint = new DOMPoint(event.pageX, event.pageY);  
            this.selectedCoordinate = this.map.convertPointOnPageToCoordinate(domPoint);
            console.log(this.selectedCoordinate);
            this.latitude = this.selectedCoordinate['latitude'];
            this.longitude = this.selectedCoordinate['longitude'];
            console.log(this.latitude);
            console.log(this.longitude);
            this.selectedAnnotation = new mapkit.MarkerAnnotation(this.selectedCoordinate);
            this.map.addAnnotation(this.selectedAnnotation);
            this.reverseGeocode();
        },
        reverseGeocode() {
            var geocoder = new mapkit.Geocoder({
                language: "en",
                getsUserLocation: true
            }).reverseLookup(this.selectedCoordinate, (err, data) => {
                console.log('wo');
                console.log(data);
            
                this.country = data.results[0].country;
                this.selectedCountryCode = data.results[0].countryCode;
                this.selectedCity = data.results[0].locality;
                this.selectedState = data.results[0].administrativeArea;
                this.postalCode = data.results[0].postCode;
                this.formatOutput();
                this.getWeather();
                this.getCityId();
                this.getCovid();
                this.getCovidUS();
            });
        },
        formatOutput() {
            this.cityOutput = this.selectedCity + ", " + this.selectedState;
            console.log(this.cityOutput);
        },
        backButton() {
            $('#eventsPage').hide();
            $('#infoPage').hide();
            $('#mainPage').show();
        },
        toggleEvents() {
            $('#eventsPage').show();
            $('#mainPage').hide();
    
            this.eventFunction();
        },
        toggleInfo(){
            $('#infoPage').show();
            $('#mainPage').hide();
            console.log('wut');
            console.log(this.cityOutput);
        },
        eventFunction() {
            console.log(this.postalCode);
            this.events = [];
            let url = "https://app.ticketmaster.com/discovery/v2/events.json?postalCode=" + this.postalCode + "&radius=100&units=miles&sort=date,asc&apikey=1ExblcQfbppYk6qJ6tD13y4IUf3tlot3"
            axios.get(url)
            .then(function (response) {
                console.log(response);
                if (!("_embedded" in response.data)) {
                    console.log("No data available in area");
                    this.isData = false;
                    return;
                }
                if (!('events' in response.data._embedded)) {
                    console.log("No data available in area");
                    this.isData = false;
                    return;
                }
                this.isData = true;
                let eventList = response.data._embedded.events;
                for (i in eventList) {
                    let event = {
                        name: eventList[i].name,
                        link: eventList[i].url,
                        image: 'No Image',
                        date: eventList[i].dates.start.localDate,
                        time: eventList[i].dates.start.localTime,
                        venue: 'No Venue Found',
                        address: 'No Address Found'
                    }
                    if ("images" in eventList[i] && eventList[i].images.length > 0) {
                        event.image = eventList[i].images[0].url
                    }
                    if ("_embedded" in eventList[i] && "venues" in eventList[i]._embedded) {
                        event.venue = eventList[i]._embedded.venues[0].name,
                        event.address = eventList[i]._embedded.venues[0].address.line1
                    }
                    // Fix date formatting
                    let year = event.date.substring(0, 4);
                    let month = event.date.substring(5, 7);
                    let day = event.date.substring(8, 10);
                    event.date = month + '/' + day + '/' + year;

                    // Fix time formatting
                    let hour = event.time.substring(0,2);
                    let min = event.time.substring(3,5);
                    if (parseInt(hour) > 12) {
                        event.time = (parseInt(hour) - 12).toString() + ':' + min + 'PM'
                    } else {
                        event.time = hour + ':' + min + 'AM'
                    }
                    this.events.push(event);
                }
            }.bind(this))
            .catch (function (error) {
                console.log(error)
            })
        }
    }
})

// function selectRegion(latCoord, longCoord) {
//     // code that selects region of map to show
//     // var region = new mapkit.CoordinateRegion(
//     //     userCoord,
//     //     new mapkit.CoordinateSpan(0.167647972, 0.354985255)
//     //     new mapkit.CoordinateSpan(latCoord, longCoord)
//     // );
//     //map.region = region;
// }




