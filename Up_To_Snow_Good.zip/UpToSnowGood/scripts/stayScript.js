
var resultView = new Vue({
    el: '#app',
    data: {
        michiganData : [
            {
                "placeName": "University of Michigan Museum of Art",
                "address": "525 South State Street",
                "description": "The museum is home to the newly renovated Alumni Memorial Hall, the Maxine and Stuart Frankel and the Frankel Family Wing and features a comprehensive collection of more than 19,000 works that spans an array of periods, cultures and forms of media. The collection boasts works by Pablo Picasso, Franz Kline, Claude Monet, Randolph Rogers and Kara Walker, and represents over 150 years of art collection at the University.",
                "picture": "images/i1.jpg",
                "link": "https://umma.umich.edu/"
            },
            {
                "placeName": "Ann Arbor Hands-On Museum",
                "address": "220 E. Ann Street,",
                "description": "Established in a historic firehouse in downtown Ann Arbor 33 years ago, the museum quickly grew to become the cornerstone of science education in the community and today boasts over 20,000 square feet of exhibition space with more than 250 interactive displays devoted to promoting science and literacy.",
                "picture": "images/i2.jpg",
                "link": "https://www.aahom.org/"
            },
            {
                "placeName": "University of Michigan School of Music, Theatre & Dance",
                "address": "1100 Baits Drive",
                "description": "Founded in 1880, it was known as the Ann Arbor School of Music and later became a part of the university. Well-known alumni include Jessye Norman, Arthur Miller, James Earl Jones, Lucy Liu, and many others. The school presents musicals, operas, plays, and dance performances. There are a variety of music ensembles,including three orchestras, three choirs, several jazz ensembles, a wind ensemble, and several chamber music groups. The Earl V. Moore building was designed by Eero Saarinen.",
                "picture": "images/i3.jpg",
                "link": "https://smtd.umich.edu/"
            },
            {
                "placeName": "University of Michigan Museum of Natural History",
                "address": "1109 Geddes Avenue",
                "description": "The collection began in 1837 and the museum’s current home, the Alexander Ruthven Museums Building, was constructed in 1928. There are four permanent exhibits including the Anthropology Displays, the Geology Displays, the Hall of Evolution, and the Michigan Wildlife Gallery. The museum also has a planetarium and a “Butterfly and Pollinator Garden.”",
                "picture": "images/i4.jpg",
                "link": "https://lsa.umich.edu/ummnh/"
            },
            {
                "placeName": "Matthaei Botanical Gardens & Nichols Arboretum",
                "address": "1800 N. Dixboro Rd",
                "description": "Matthaei Botanical Gardens and Nichols Arboretum are two properties operated by the University of Michigan that feature an array of botanical and display gardens, a conservatory, natural areas with hiking and walking trails, and several research-quality habitats.",
                "picture": "images/i5.jpg",
                "link": "https://mbgna.umich.edu/"
            },
            {
                "placeName": "Gerald R. Ford Presidential Library",
                "address": "1000 Beal Ave",
                "description": "The Gerald R. Ford Presidential Library and Museum is located on the north campus of the University of Michigan. One of thirteen presidential libraries administered by the National Archives and Records Administration, the Gerald R. Ford Presidential Library is a valuable repository that houses important items on the life, career, and presidency of Gerald Ford, the 38th President of the United States of America.",
                "picture": "images/i6.jpg",
                "link": "https://www.fordlibrarymuseum.gov/"
            },
            {
                "placeName": "Power Center for the Performing Arts",
                "address": "121 Fletcher Street",
                "description": "The Power Center for the Performing Arts is a multi-purpose center and performance space. In 1963 Eugene and Sadye Power donated funds for the construction of the center. Designed in a style referred to as modern classical, the center opened in 1971. The theater was modeled after a Greek theater at Epidarus: there are no seats in the Power Center that are more than 80 feet from the stage.",
                "picture": "images/i7.jpg",
                "link": "https://arts.umich.edu/museums-cultural-attractions/power-center/"
            },
            {
                "placeName": "Michigan Theater",
                "address": "603 East Liberty Street",
                "description": "Michigan Theater is a movie palace that screens independent films and presents music concerts and stage productions. With a seating capacity of 1,700, the theater includes lobbies, a functional stage, and an orchestra pit.",
                "picture": "images/i8.jpg",
                "link": "https://www.michtheater.org/"
            },
            {
                "placeName": "The Creature Conservancy",
                "address": "4940 Ann Arbor-Saline Road",
                "description": "The Creature Conservancy is an animal rescue and educational organization dedicated to rescuing animals and getting the community involved by educating them about the animals. There are several exhibits including Aquatic Exotics that features apple snails, African clawed frogs, and water hyacinths; McCalls of the Wild for macaws; ‘Roo Room for kangaroos; and Vulture Club for vultures.",
                "picture": "images/i9.jpg",
                "link": "http://www.thecreatureconservancy.org/"
            },
            {
                "placeName": "The Petting Farm",
                "address": "3001 Earhart Road",
                "description": "The Petting Farm lets children learn about animals and the agricultural history of Michigan. The Petting Farm began in 1925 as a working farm but was bought in the 1980s for the construction of an office complex. The original red barn was moved across the road and sits on 20 acres of land. Opened in 1994, the Petting Farm is a fun and educational experience for families and school groups.",
                "picture": "images/i10.jpg",
                "link": "https://www.pettingfarm.com/"
            }
        
        ]
    }
  })
  